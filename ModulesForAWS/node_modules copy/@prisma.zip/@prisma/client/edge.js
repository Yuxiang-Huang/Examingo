module.exports = {
  ...require('.prisma/client/edge'),
}
