module.exports = {
  ...require('./scripts/default-index'),
}
