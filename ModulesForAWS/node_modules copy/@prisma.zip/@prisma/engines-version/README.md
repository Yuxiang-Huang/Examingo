# `@prisma/engines-version`

This package exports the Prisma Engines version to be downloaded from Prisma CDN.

⚠️ **Warning**: This package is intended for Prisma's internal use.
Its release cycle does not follow SemVer, which means we might release breaking changes (change APIs, remove functionality) without any prior warning.

See its companion, [`@prisma/engines` npm package](https://www.npmjs.com/package/@prisma/engines).
