
GeoMet

Convert GeoJSON to WKT/WKB (Well-Known Text/Binary), and vice versa.


